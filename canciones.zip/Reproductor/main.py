from Views.interfaz import Reproductor


class  Main ():
    def main ():
        App = Reproductor()
    main()









